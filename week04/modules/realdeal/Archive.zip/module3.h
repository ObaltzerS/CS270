// header file
#include "module3.cpp"
// this is the interface
int sum(int num1, int num2); // advanced decleration

void printstars(int width, int height);
