//main file
#include "module3.h"
#include <iostream>
using namespace std;

int main(){
    cout << sum(5,2); // calling the sum function from module3
    printstars(5, 5);
    return 0;
}
